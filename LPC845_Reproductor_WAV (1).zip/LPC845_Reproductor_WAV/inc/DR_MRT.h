/*******************************************************************************************************************************//**
 *
 * @file		DR_MRT.h
 * @brief		Breve descripción del objetivo del Módulo
 * @date		Jan 8, 2022
 * @author		Federico Speroni
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MODULO
 **********************************************************************************************************************************/

#ifndef DR_MRT_H_
#define DR_MRT_H_

/***********************************************************************************************************************************
 *** INCLUDES GLOBALES
 **********************************************************************************************************************************/
#include <stdint.h>
#include "DR_Tipos.h"

/***********************************************************************************************************************************
 *** DEFINES GLOBALES
 **********************************************************************************************************************************/
/* MRT - Peripheral instance base addresses */
/** Peripheral MRT0 base address */
#define MRT_BASE                                (0x40004000U)

/** Peripheral MRT0 base pointer */
#define MRT0                                    ((MRT_Type *) MRT_BASE)
/***********************************************************************************************************************************
 *** MACROS GLOBALES
 **********************************************************************************************************************************/
/*! @name CHANNEL_INTVAL - MRT Time interval value register. This value is loaded into the TIMER register. */
/*! @{ */
#define MRT_CHANNEL_INTVAL_IVALUE_MASK           (0x7FFFFFFFU)
#define MRT_CHANNEL_INTVAL_IVALUE_SHIFT          (0U)
#define MRT_CHANNEL_INTVAL_IVALUE(x)             (((uint32_t)(((uint32_t)(x)) << MRT_CHANNEL_INTVAL_IVALUE_SHIFT)) & MRT_CHANNEL_INTVAL_IVALUE_MASK)
#define MRT_CHANNEL_INTVAL_LOAD_MASK             (0x80000000U)
#define MRT_CHANNEL_INTVAL_LOAD_SHIFT            (31U)
/*! LOAD - Determines how the timer interval value IVALUE -1 is loaded into the TIMERn register.
 *    This bit is write-only. Reading this bit always returns 0.
 *  0b0..No force load. The load from the INTVALn register to the TIMERn register is processed at the end of the
 *       time interval if the repeat mode is selected.
 *  0b1..Force load. The INTVALn interval value IVALUE -1 is immediately loaded into the TIMERn register while TIMERn is running.
 */
#define MRT_CHANNEL_INTVAL_LOAD(x)               (((uint32_t)(((uint32_t)(x)) << MRT_CHANNEL_INTVAL_LOAD_SHIFT)) & MRT_CHANNEL_INTVAL_LOAD_MASK)

/***********************************************************************************************************************************
 *** TIPO DE DATOS GLOBALES - Enumeraciones
 **********************************************************************************************************************************/
/*! @brief List of MRT channels */
typedef enum _MRT_chnl
{
	MRT_CHANNEL_0 = 0,
	MRT_CHANNEL_1,
	MRT_CHANNEL_2,
	MRT_CHANNEL_3
}MRT_channel_sel_en;

/*! @brief List of MRT timer modes */
typedef enum _MRT_timer_mode
{
	MRT_MODE_REPEAT = 0,
	MRT_MODE_ONE_SHOT,
	MRT_MODE_ONE_SHOT_BUS_STALL
}MRT_timer_mode_en;

/*! @brief List of MRT interrupt status*/
typedef enum _MRT_interrupt_enable
{
	MRT_TimerInterruptDisable = 0U,
	MRT_TimerInterruptEnable = 1U  	/*!< Timer interrupt enable*/
}MRT_interrupt_enable_en;

/***********************************************************************************************************************************
 *** TIPO DE DATOS GLOBALES - Estructuras
 **********************************************************************************************************************************/
typedef struct
{
	uint32_t LVALUE : 31;
	uint32_t LOAD : 1;
}MRT_INTVAL_reg_t;

typedef struct
{
	uint32_t VALUE : 31;
	uint32_t : 1;
}MRT_TIMER_reg_t;

typedef struct
{
	uint32_t INTEN : 1;
	uint32_t MODE : 2;
	uint32_t : 29;
}MRT_CTRL_reg_t;

typedef struct
{
	uint32_t INTFLAG : 1;
	uint32_t RUN : 1;
	uint32_t : 30;
}MRT_STAT_reg_t;

typedef struct
{
	uint32_t : 4;
	uint32_t CHAN : 4;
	uint32_t : 24;
}MRT_IDLE_CH_reg_t;

typedef struct
{
	uint32_t CFLAG0 : 1;
	uint32_t CFLAG1 : 1;
	uint32_t CFLAG2 : 1;
	uint32_t CFLAG3 : 1;
	uint32_t : 28;
}MRT_IRQ_FLAG_reg_t;

typedef struct
{
	MRT_INTVAL_reg_t INTVAL;
	const MRT_TIMER_reg_t TIMER;
	MRT_CTRL_reg_t CTRL;
	MRT_STAT_reg_t STAT;
}MRT_CHN_reg_t;

typedef struct
{
	__RW MRT_CHN_reg_t CHN[4];
	const uint32_t RESERVED[45];
	__R MRT_IDLE_CH_reg_t IDLE_CH;
	__RW MRT_IRQ_FLAG_reg_t IRQ_FLAG;
}MRT_per_t;

/** MRT - Register Layout Typedef */
typedef struct {
  struct {                                         /* offset: 0x0, array step: 0x10 */
    __RW uint32_t INTVAL;                            /**< MRT Time interval value register. This value is loaded into the TIMER register., array offset: 0x0, array step: 0x10 */
    __R  uint32_t TIMER;                             /**< MRT Timer register. This register reads the value of the down-counter., array offset: 0x4, array step: 0x10 */
    __RW uint32_t CTRL;                              /**< MRT Control register. This register controls the MRT modes., array offset: 0x8, array step: 0x10 */
    __RW uint32_t STAT;                              /**< MRT Status register., array offset: 0xC, array step: 0x10 */
  } CHANNEL[4];
       uint8_t RESERVED_0[180];
  __R  uint32_t IDLE_CH;                           /**< Idle channel register. This register returns the number of the first idle channel., offset: 0xF4 */
  __RW uint32_t IRQ_FLAG;                          /**< Global interrupt flag register, offset: 0xF8 */
} MRT_Type;

/*******************	****************************************************************************************************************
 *** VARIABLES GLOBALES
 **********************************************************************************************************************************/
// extern tipo nombreVariable;

/***********************************************************************************************************************************
 *** PROTOTIPOS DE FUNCIONES GLOBALES
 **********************************************************************************************************************************/
void MRT_load_interval_value(MRT_channel_sel_en channel, uint32_t interval);
void MRT_set_interval_and_force_load(MRT_channel_sel_en channel, uint32_t interval);
void MRT_set_interval_and_stop_timer(MRT_channel_sel_en channel, uint32_t interval);
uint32_t MRT_get_current_value(MRT_channel_sel_en channel);
void MRT_enable_irq(MRT_channel_sel_en channel);
void MRT_disable_irq(MRT_channel_sel_en channel);
void MRT_config_mode(MRT_channel_sel_en channel, MRT_timer_mode_en mode);
uint8_t MRT_get_idle_channel(void);
uint8_t MRT_get_irq_flag(MRT_channel_sel_en channel);
void MRT_clear_irq_flag(MRT_channel_sel_en channel);
uint32_t MRT_Value (uint32_t timer_n);

#endif /* DR_MRT_H_ */

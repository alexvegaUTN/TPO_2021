/*******************************************************************************************************************************//**
 *
 * @file		PR_MRT.h
 * @brief		Breve descripción del objetivo del Módulo
 * @date		Feb 20, 2022
 * @author		Federico Speroni
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MODULO
 **********************************************************************************************************************************/

#ifndef PR_MRT_H_
#define PR_MRT_H_

/***********************************************************************************************************************************
 *** INCLUDES GLOBALES
 **********************************************************************************************************************************/
#include <stdint.h>
#include "DR_Tipos.h"


/***********************************************************************************************************************************
 *** DEFINES GLOBALES
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MACROS GLOBALES
 **********************************************************************************************************************************/
#define MRT_CHANNEL_CTRL_MODE_SHIFT              (1U)
#define MRT_CHANNEL_CTRL_INTEN_MASK              (0x1U)
#define MRT_CHANNEL_STAT_INTFLAG_MASK            (0x1U)
#define MRT_CHANNEL_STAT_RUN_MASK                (0x2U)

/***********************************************************************************************************************************
 *** TIPO DE DATOS GLOBALES
 **********************************************************************************************************************************/
/*! @brief List of MRT time units */
typedef enum _mrt_unit
{
    k_sec = 1U, 			/*!< seconds */
    k_mSec = 1000U,      	/*!< miliseconds */
    k_uSec = 1000000U      	/*!< microseconds */
} mrt_unit_e;

/*! @brief List of MRT channels */
typedef enum _mrt_chnl
{
    kMRT_Channel_0 = 0U, /*!< MRT channel number 0*/
    kMRT_Channel_1,      /*!< MRT channel number 1 */
    kMRT_Channel_2,      /*!< MRT channel number 2 */
    kMRT_Channel_3       /*!< MRT channel number 3 */
} mrt_channel_e;

/*! @brief List of MRT timer modes */
typedef enum _mrt_timer_mode
{
    kMRT_RepeatMode       = (0 << MRT_CHANNEL_CTRL_MODE_SHIFT), /*!< Repeat Interrupt mode */
    kMRT_OneShotMode      = (1 << MRT_CHANNEL_CTRL_MODE_SHIFT), /*!< One-shot Interrupt mode */
    kMRT_OneShotStallMode = (2 << MRT_CHANNEL_CTRL_MODE_SHIFT)  /*!< One-shot stall mode */
} mrt_timer_mode_e;

/*! @brief List of MRT interrupts */
typedef enum _mrt_interrupt_enable
{
	kMRT_TimerInterruptDisable = 0,
	kMRT_TimerInterruptEnable = MRT_CHANNEL_CTRL_INTEN_MASK  /*!< Timer interrupt enable*/
} mrt_interrupt_enable_e;

/*! @brief List of MRT status flags */
typedef enum _mrt_status_flags
{
    kMRT_TimerInterruptFlag = MRT_CHANNEL_STAT_INTFLAG_MASK, /*!< Timer interrupt flag */
    kMRT_TimerRunFlag       = MRT_CHANNEL_STAT_RUN_MASK,     /*!< Indicates state of the timer */
} mrt_status_flags_e;

/**
 * @brief Tipo de dato para la callback del Multi Rate Timer (MRT).
 * @note Callback ejecutados desde un contexto de interrupción, por lo que el usuario deberá tener
 * todas las consideraciones necesarias al respecto.
 */
typedef void (*mrt_callback_fp)(mrt_channel_e);

/*! @brief MRT configuration struct */
typedef struct {
	mrt_channel_e channel;
	mrt_timer_mode_e mode;
	mrt_interrupt_enable_e intEnable;
	uint32_t time;
	mrt_unit_e unit;
	//void (*tx_free_callback)(void);
	mrt_callback_fp mrt_ready_callback; 	/**< Callback a ejecutar cuando venció la cuenta del timer */
}mrt_config_t;

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES
 **********************************************************************************************************************************/
// extern tipo nombreVariable;

/***********************************************************************************************************************************
 *** PROTOTIPOS DE FUNCIONES GLOBALES
 **********************************************************************************************************************************/
void mrt_init(const mrt_config_t * mrt_config);
void mrt_enable_irq(mrt_channel_e channel);
void mrt_disable_irq(mrt_channel_e channel);
uint8_t mrt_get_irq_status(mrt_channel_e channel);
void mrt_set_interval_and_force_load(mrt_channel_e channel, uint32_t interval);
uint32_t mrt_set_time_period(mrt_channel_e channel, uint32_t clk_freq, uint32_t time, mrt_unit_e unit);
void mrt_register_callback(mrt_channel_e channel, mrt_callback_fp new_callback);

#endif /* PR_MRT_H_ */

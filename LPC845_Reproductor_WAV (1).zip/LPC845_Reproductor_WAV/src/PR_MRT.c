/*******************************************************************************************************************************//**
 *
 * @file		PR_MRT.c
 * @brief		Descripcion del modulo
 * @date		Feb 20, 2022
 * @author		Federico Speroni
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/
#include "PR_MRT.h"
#include "DR_MRT.h"
#include "DR_SYSCON.h"
#include "DR_NVIC.h"
#include "PR_SYSCON.h"

/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/
static uint8_t mrt_flag_irq_status[] = {0, 0, 0, 0};

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/
void mrt_configuration(const mrt_config_t * mrt_config);
static void dummy_callback(mrt_channel_e channel);
static void mrt_irq_handler(MRT_channel_sel_en channel);
static void mrt_set_irq_flag_status(mrt_channel_e channel);
static void mrt_clear_irq_flag_status(mrt_channel_e channel);

static void (*p_mrt_callback[])(mrt_channel_e) = 	//!< Callbacks registrados para atender interrupcion de MRT
{
	dummy_callback,
	dummy_callback,
	dummy_callback,
	dummy_callback
};

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/
/*
 * @brief Funcion dummy para inicialiar punteros de interrupcion
 */
static void dummy_callback(mrt_channel_e channel)
{
	return;
}

/**
 * @brief Manejador generico de interrupciones de MRT
 * @param[in] inst Instancia que genero la interrupcion
 */
static void mrt_irq_handler(MRT_channel_sel_en channel)
{
	if (MRT_get_irq_flag(channel)) {
		p_mrt_callback[channel](channel);
	}
}

void mrt_configuration(const mrt_config_t * mrt_config)
{
	MRT_config_mode(mrt_config->channel, mrt_config->mode);
}

void mrt_set_irq_flag_status(mrt_channel_e channel)
{
	mrt_flag_irq_status[channel] = 1;
}

void mrt_clear_irq_flag_status(mrt_channel_e channel)
{
	mrt_flag_irq_status[channel] = 0;
}
 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/
/**
	\fn  Nombre de la Funcion
	\brief Descripcion
 	\author Federcio Speroni
 	\date Feb 20, 2022
 	\param [in] parametros de entrada
 	\param [out] parametros de salida
	\return tipo y descripcion de retorno
*/

void mrt_init(const mrt_config_t * mrt_config)
{
	// 1 - Enable clock to Multi Rate Timer module
	SYSCON_enable_clock(SYSCON_ENABLE_CLOCK_SEL_MRT);

	// 2 - Reset Multi Rate Timer module
	SYSCON_clear_reset(SYSCON_RESET_SEL_MRT);

	// 3 - Enable MRT Global Interrupt
	NVIC_enable_interrupt(NVIC_IRQ_SEL_MRT);			// Global Interrupts

	// 3 - Enable MRT Interrupt and register callback
	mrt_register_callback(mrt_config->channel, mrt_config->mrt_ready_callback);

	mrt_configuration(mrt_config);
	//mrt_set_time_period(mrt_config->channel, syscon_get_main_clk_freq(), 0, mrt_config->unit);
}

/**
 * @brief Fijar intervalo de un canal del MRT sin detener el conteo actual
 * @param[in] channel Canal a configurar
 * @param[in] interval Intervalo a cargar
 */
void mrt_set_interval_and_force_load(mrt_channel_e channel, uint32_t interval)
{
	MRT_set_interval_and_force_load((MRT_channel_sel_en)channel, interval);
}

/**
 * @brief Registrar el callback a ser llamado en la recepcion de un dato por USART
 * @param[in] inst A que instancia de USART registrar el callback
 * @param[in] new_callback Callback a ejectutar cada vez que se recibe un dato por USART
 * @note Recordar que estos callbacks se ejecutan en el contexto de una interrupción, por lo que se deberán
 * tener todas las consideraciones encesarias en el mismo.
 */
void mrt_register_callback(mrt_channel_e channel, mrt_callback_fp new_callback)
{
	if(new_callback == NULL) {
		MRT_disable_irq((MRT_channel_sel_en)channel);
		p_mrt_callback[channel] = dummy_callback;
	}
	else {
		MRT_enable_irq((MRT_channel_sel_en)channel);
		p_mrt_callback[channel] = new_callback;
	}
}

/*
 * @brief Habilitar interrupcion en un canal del MRT
 * @param[in] channel Canal a configurar
 */
void mrt_enable_irq(mrt_channel_e channel)
{
	//MRT->CHN[channel].CTRL.INTEN = 1;
	MRT_enable_irq((MRT_channel_sel_en)channel);
	mrt_set_irq_flag_status(channel);
}

/*
 * @brief Inhabilitar interrupcion en un canal del MRT
 * @param[in] channel Canal a configurar
 */
void mrt_disable_irq(mrt_channel_e channel)
{
	//MRT->CHN[channel].CTRL.INTEN = 0;
	MRT_disable_irq(channel);
	mrt_clear_irq_flag_status(channel);
}

/*
 * @brief leer el estado de habilitacion de la interrupcion
 * @param[in] channel Canal a leer el estado de la interrupci'on
 */
uint8_t mrt_get_irq_status(mrt_channel_e channel)
{
	return mrt_flag_irq_status[channel];
}

uint32_t mrt_set_time_period(mrt_channel_e channel, uint32_t clk_freq, uint32_t time, mrt_unit_e unit)
{
	uint32_t count = 0;

	if (channel > kMRT_Channel_3) {
		return count;
	}

	uint32_t ivalue = (double)clk_freq * ((double)time / (double)unit);

	if (ivalue <= MRT_CHANNEL_INTVAL_IVALUE_MASK) {
		//MRT_load_interval_value(channel, ivalue);
		MRT_set_interval_and_stop_timer(channel, ivalue);
		count = ivalue;
	}

	return count;
}

/**
 * @brief Interrupcion de MRT
 */
void MRT_IRQHandler(void)
{
	mrt_irq_handler(MRT_CHANNEL_0);
}

